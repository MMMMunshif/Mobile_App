package com.example.bookaura

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.bookaura.model.Book

class BookAdapter(
    private val items: List<Book>
) : RecyclerView.Adapter<BookAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.ivCover)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val author: TextView = v.findViewById(R.id.tvAuthor)
        val price: TextView = v.findViewById(R.id.tvPrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_book, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val b = items[pos]
        h.img.setImageResource(b.coverRes)
        h.title.text = b.title
        h.author.text = b.author
        h.price.text = b.price

        // Open details on whole card tap
        h.itemView.setOnClickListener {
            val ctx = it.context
            val i = Intent(ctx, DetailsActivity::class.java).apply {
                putExtra("title", b.title)
                putExtra("author", b.author)
                putExtra("price", b.price)
                putExtra("cover", b.coverRes)
                putExtra("desc", b.desc)
            }
            ctx.startActivity(i)
        }
    }

    override fun getItemCount() = items.size
}
