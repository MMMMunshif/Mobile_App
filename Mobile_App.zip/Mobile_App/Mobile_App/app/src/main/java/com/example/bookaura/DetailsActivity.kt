package com.example.bookaura

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val tvTitle = findViewById<TextView>(R.id.tvDetailsTitle)
        val tvAuthor = findViewById<TextView>(R.id.tvDetailsAuthor)
        val tvPrice = findViewById<TextView>(R.id.tvDetailsPrice)
        val imgCover = findViewById<ImageView>(R.id.imgCover)
        val tvDesc = findViewById<TextView>(R.id.tvDetailsDesc)

        val title = intent.getStringExtra("title") ?: getString(R.string.book1_title)
        val price = intent.getStringExtra("price") ?: getString(R.string.book1_price)
        val author = intent.getStringExtra("author") ?: getString(R.string.book1_author)
        val cover = intent.getIntExtra("cover", R.drawable.book1_cover)
        val desc  = intent.getStringExtra("desc") ?: getString(R.string.book1_desc)

        tvTitle.text = title
        tvAuthor.text = author
        tvPrice.text = price
        imgCover.setImageResource(cover)
        tvDesc.text = desc

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<Button>(R.id.btnAddToCart).setOnClickListener {
            startActivity(Intent(this, PaymentActivity::class.java))
        }


    }
}
