package com.example.bookaura

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bookaura.model.Book

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val rv = findViewById<RecyclerView>(R.id.rvBooks)
        rv.layoutManager = GridLayoutManager(this, 2)
        rv.addItemDecoration(SpacingDecoration(2, 12, includeEdge = false))

        val data = listOf(
            Book(getString(R.string.book1_title), getString(R.string.book1_author), getString(R.string.book1_price), R.drawable.book1_cover, getString(R.string.book1_desc)),
            Book(getString(R.string.book2_title), getString(R.string.book2_author), getString(R.string.book2_price), R.drawable.book2_cover, getString(R.string.book2_desc)),
            Book(getString(R.string.book3_title), getString(R.string.book3_author), getString(R.string.book3_price), R.drawable.book3_cover, getString(R.string.book3_desc)),
            Book(getString(R.string.book4_title), getString(R.string.book4_author), getString(R.string.book4_price), R.drawable.book4_cover, getString(R.string.book4_desc)),
            Book(getString(R.string.book5_title), getString(R.string.book5_author), getString(R.string.book5_price), R.drawable.book5_cover, getString(R.string.book5_desc)),
            Book(getString(R.string.book6_title), getString(R.string.book6_author), getString(R.string.book6_price), R.drawable.book6_cover, getString(R.string.book6_desc)),
            Book(getString(R.string.book7_title), getString(R.string.book7_author), getString(R.string.book7_price), R.drawable.book7_cover, getString(R.string.book7_desc)),
            Book(getString(R.string.book8_title), getString(R.string.book8_author), getString(R.string.book8_price), R.drawable.book8_cover, getString(R.string.book8_desc)),
            Book(getString(R.string.book9_title), getString(R.string.book9_author), getString(R.string.book9_price), R.drawable.book9_cover, getString(R.string.book9_desc)),
            Book(getString(R.string.book10_title), getString(R.string.book10_author), getString(R.string.book10_price), R.drawable.book10_cover, getString(R.string.book10_desc))
        )
        rv.adapter = BookAdapter(data)

        findViewById<ImageButton>(R.id.btnProfile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }


        // 🔹 Payment Button click listener
        val btnPayment = findViewById<ImageButton>(R.id.btnCart)
        btnPayment.setOnClickListener {
            val intent = Intent(this, PaymentActivity::class.java)
            startActivity(intent)
        }
    }
}
