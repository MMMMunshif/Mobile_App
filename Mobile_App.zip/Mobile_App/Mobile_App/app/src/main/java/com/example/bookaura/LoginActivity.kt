package com.example.bookaura

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("auth", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvToSignup = findViewById<TextView>(R.id.tvToSignup)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val pass = etPassword.text.toString()

            if (email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, getString(R.string.err_fill_all), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Very simple local check (from signup)
            val savedEmail = prefs.getString("email", null)
            val savedPass = prefs.getString("password", null)

            if (savedEmail == null || savedPass == null) {
                Toast.makeText(this, getString(R.string.err_no_account), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (email == savedEmail && pass == savedPass) {
                prefs.edit().putBoolean("logged_in", true).apply()
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, getString(R.string.err_invalid_creds), Toast.LENGTH_SHORT).show()
            }
        }

        tvToSignup.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }
    }
}
