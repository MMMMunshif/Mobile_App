package com.example.bookaura

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("auth", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Read what we saved at Signup (fallbacks shown if null)
        val name  = prefs.getString("name",  "User") ?: "User"
        val email = prefs.getString("email", "user@example.com") ?: "user@example.com"
        val phone = prefs.getString("phone", "+94 7XXXXXXXX") ?: "+94 7XXXXXXXX"
        val addr  = prefs.getString("address", "Colombo") ?: "Colombo"

        findViewById<TextView>(R.id.tvName).text = name
        findViewById<TextView>(R.id.tvEmail).text = email
        findViewById<TextView>(R.id.tvPhone).text = phone
        findViewById<TextView>(R.id.tvAddress).text = addr

        // Optional: back
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { finish() }

        // Logout: super simple (no confirm)
        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            prefs.edit().putBoolean("logged_in", false).apply()
            startActivity(Intent(this, LoginActivity::class.java))
            finishAffinity()
        }
    }
}
