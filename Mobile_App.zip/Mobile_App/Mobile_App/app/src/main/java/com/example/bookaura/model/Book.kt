package com.example.bookaura.model

data class Book(
    val title: String,
    val author: String,
    val price: String,
    val coverRes: Int,
    val desc: String
)
